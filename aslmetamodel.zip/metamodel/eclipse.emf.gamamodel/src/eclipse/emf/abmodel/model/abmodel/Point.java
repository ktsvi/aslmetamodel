/**
 */
package eclipse.emf.abmodel.model.abmodel;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Point</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see eclipse.emf.abmodel.model.abmodel.AbmodelPackage#getPoint()
 * @model
 * @generated
 */
public interface Point extends SpatialEntity {
} // Point
