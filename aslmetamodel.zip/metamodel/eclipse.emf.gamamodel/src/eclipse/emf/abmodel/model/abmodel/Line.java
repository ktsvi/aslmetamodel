/**
 */
package eclipse.emf.abmodel.model.abmodel;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Line</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see eclipse.emf.abmodel.model.abmodel.AbmodelPackage#getLine()
 * @model
 * @generated
 */
public interface Line extends SpatialEntity {
} // Line
